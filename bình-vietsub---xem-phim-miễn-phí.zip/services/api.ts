
const BASE_URL = 'https://phimapi.com';

// Cache object to store API responses
const apiCache: Record<string, { data: any; timestamp: number }> = {};
const CACHE_TTL = 1000 * 60 * 5; // 5 minutes

const fetchWithCache = async (url: string) => {
  const now = Date.now();
  if (apiCache[url] && now - apiCache[url].timestamp < CACHE_TTL) {
    return apiCache[url].data;
  }

  const res = await fetch(url);
  if (!res.ok) throw new Error('Network response was not ok');
  
  const data = await res.json();
  apiCache[url] = { data, timestamp: now };
  return data;
};

export const getImageUrl = (path: string) => {
  if (!path) return 'https://placehold.co/400x600/1a1a1a/ffffff?text=No+Image';
  if (path.startsWith('http')) return path;
  return `https://phimimg.com/${path}`;
};

export const fetchNewUpdates = async (page = 1) => {
  return fetchWithCache(`${BASE_URL}/danh-sach/phim-moi-cap-nhat?page=${page}`);
};

export const fetchListByType = async (type: string, page = 1) => {
  return fetchWithCache(`${BASE_URL}/v1/api/danh-sach/${type}?page=${page}`);
};

export const fetchMovieDetail = async (slug: string) => {
  return fetchWithCache(`${BASE_URL}/phim/${slug}`);
};

export const searchMovies = async (keyword: string, page = 1) => {
  return fetchWithCache(`${BASE_URL}/v1/api/tim-kiem?keyword=${encodeURIComponent(keyword)}&page=${page}`);
};

export const fetchGenres = async () => {
  return fetchWithCache(`${BASE_URL}/the-loai`);
};

export const fetchCountries = async () => {
  return fetchWithCache(`${BASE_URL}/quoc-gia`);
};


import React, { useState, useEffect } from 'react';
import { HistoryItem } from '../types';
import { Link } from 'react-router-dom';
import { Clock, Play, Trash2, Bookmark, Heart, Loader2 } from 'lucide-react';
import { getImageUrl } from '../services/api';

const Library: React.FC = () => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'history' | 'bookmarks'>('history');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedHistory = JSON.parse(localStorage.getItem('phim_history') || '[]');
    const savedBookmarks = JSON.parse(localStorage.getItem('phim_bookmarks') || '[]');
    setHistory(savedHistory);
    setBookmarks(savedBookmarks);
    setLoading(false);
  }, []);

  const clearHistory = () => {
    if (confirm('Bạn có chắc muốn xóa toàn bộ lịch sử xem?')) {
      localStorage.removeItem('phim_history');
      setHistory([]);
    }
  };

  const removeHistoryItem = (slug: string) => {
    const updated = history.filter(item => item.slug !== slug);
    localStorage.setItem('phim_history', JSON.stringify(updated));
    setHistory(updated);
  };

  const removeBookmark = (slug: string) => {
    const updated = bookmarks.filter(b => b.slug !== slug);
    localStorage.setItem('phim_bookmarks', JSON.stringify(updated));
    setBookmarks(updated);
  };

  if (loading) {
     return <div className="h-[70vh] flex items-center justify-center"><Loader2 className="w-10 h-10 animate-spin text-red-600" /></div>;
  }

  return (
    <div className="max-w-[1440px] mx-auto px-4 md:px-12 py-16 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-8">
        <div>
           <h1 className="text-5xl font-black uppercase tracking-tighter mb-2">Thư viện cá nhân</h1>
           <p className="text-gray-500 font-bold uppercase tracking-widest text-[10px]">Quản lý nội dung bạn đã xem và yêu thích</p>
        </div>
        <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/10 shadow-2xl">
           <button 
              onClick={() => setActiveTab('history')}
              className={`px-10 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'history' ? 'bg-red-600 text-white shadow-xl' : 'text-gray-500 hover:text-white'}`}
           >
              Lịch sử xem
           </button>
           <button 
              onClick={() => setActiveTab('bookmarks')}
              className={`px-10 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'bookmarks' ? 'bg-red-600 text-white shadow-xl' : 'text-gray-500 hover:text-white'}`}
           >
              Phim yêu thích
           </button>
        </div>
      </div>

      {activeTab === 'history' ? (
        <div className="space-y-8">
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
             <h2 className="text-xl font-black uppercase tracking-tighter flex items-center gap-3">
                <Clock className="w-6 h-6 text-red-600" /> Vừa xem gần đây
             </h2>
             {history.length > 0 && (
                <button 
                  onClick={clearHistory}
                  className="text-[10px] text-red-500 hover:text-red-400 font-black uppercase tracking-[0.2em] flex items-center gap-2 px-4 py-2 bg-red-600/10 rounded-full transition-all"
                >
                  <Trash2 className="w-3 h-3" /> Xóa tất cả
                </button>
             )}
          </div>

          {history.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-8">
              {history.map((item) => (
                <div key={item.slug} className="group relative bg-[#1A1A1A] rounded-[2rem] overflow-hidden border border-white/5 hover:border-red-600/50 transition-all shadow-2xl">
                  <div className="aspect-[16/10] relative overflow-hidden">
                    <img src={getImageUrl(item.poster)} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                       <Link 
                          to={`/xem-phim/${item.slug}/${item.episodeSlug}`}
                          className="bg-red-600 p-4 rounded-full transform scale-75 group-hover:scale-100 transition-all shadow-xl"
                        >
                          <Play className="w-6 h-6 fill-current text-white" />
                       </Link>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-black text-sm truncate mb-2 uppercase tracking-tight">{item.name}</h3>
                    <div className="flex items-center justify-between">
                       <span className="bg-red-600/20 text-red-500 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">Tập {item.episodeName}</span>
                       <span className="text-[10px] font-bold text-gray-500">{new Date(item.timestamp).toLocaleDateString()}</span>
                    </div>
                    <button 
                      onClick={() => removeHistoryItem(item.slug)}
                      className="absolute top-4 right-4 p-2 bg-black/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:bg-red-600 hover:text-white"
                    >
                       <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-24 text-center space-y-6 bg-white/5 rounded-[3rem] border border-dashed border-white/10">
               <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto border border-white/5">
                  <Clock className="w-10 h-10 text-gray-600" />
               </div>
               <div>
                  <h3 className="text-2xl font-black uppercase tracking-tighter mb-2">Lịch sử trống</h3>
                  <p className="text-gray-500 font-bold text-sm">Hãy bắt đầu hành trình điện ảnh của bạn ngay bây giờ.</p>
               </div>
               <Link to="/" className="inline-block bg-red-600 px-12 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-red-600/20">Khám phá phim ngay</Link>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-8">
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
             <h2 className="text-xl font-black uppercase tracking-tighter flex items-center gap-3">
                <Heart className="w-6 h-6 text-red-600 fill-current" /> Danh sách yêu thích
             </h2>
          </div>

          {bookmarks.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-8">
              {bookmarks.map((movie) => (
                <div key={movie.slug} className="group relative bg-[#1A1A1A] rounded-[2rem] overflow-hidden border border-white/5 hover:border-red-600/50 transition-all shadow-2xl aspect-[2/3]">
                  <img src={getImageUrl(movie.thumb_url)} alt={movie.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-6 text-center">
                     <Link to={`/phim/${movie.slug}`} className="bg-red-600 p-4 rounded-full shadow-2xl transform scale-75 group-hover:scale-100 transition-all mb-4">
                        <Play className="w-6 h-6 fill-current text-white" />
                     </Link>
                     <h3 className="font-black text-sm uppercase tracking-tight mb-2">{movie.name}</h3>
                     <button 
                        onClick={() => removeBookmark(movie.slug)}
                        className="text-[10px] font-black uppercase tracking-widest text-red-500 hover:text-white"
                     >
                        Bỏ yêu thích
                     </button>
                  </div>
                  <div className="absolute top-4 right-4">
                     <button onClick={() => removeBookmark(movie.slug)} className="p-2 bg-black/60 rounded-full text-red-500 border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Heart className="w-4 h-4 fill-current" />
                     </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-24 text-center space-y-6 bg-white/5 rounded-[3rem] border border-dashed border-white/10">
               <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto border border-white/5">
                  <Bookmark className="w-10 h-10 text-gray-600" />
               </div>
               <div>
                  <h3 className="text-2xl font-black uppercase tracking-tighter mb-2">Chưa có phim lưu</h3>
                  <p className="text-gray-500 font-bold text-sm">Lưu lại những siêu phẩm để xem vào cuối tuần này.</p>
               </div>
               <Link to="/" className="inline-block bg-red-600 px-12 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-red-600/20">Tìm phim hay ngay</Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Library;

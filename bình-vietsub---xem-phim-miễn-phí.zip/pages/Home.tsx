
import React, { useEffect, useState } from 'react';
import { fetchNewUpdates, fetchListByType, getImageUrl } from '../services/api';
import { Movie, HistoryItem } from '../types';
import MovieCard from '../components/MovieCard';
import { Play, Info, ChevronRight, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { HeroSkeleton, MovieCardSkeleton } from '../components/Skeleton';

const Home: React.FC = () => {
  const [newMovies, setNewMovies] = useState<Movie[]>([]);
  const [seriesMovies, setSeriesMovies] = useState<Movie[]>([]);
  const [continueWatching, setContinueWatching] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const [recent, series] = await Promise.all([
        fetchNewUpdates(1),
        fetchListByType('phim-bo', 1),
      ]);
      setNewMovies(recent.items.slice(0, 10));
      setSeriesMovies(series.data.items.slice(0, 12));
      
      const history: HistoryItem[] = JSON.parse(localStorage.getItem('phim_history') || '[]');
      setContinueWatching(history.slice(0, 6));
    } catch (error) {
      console.error("Error loading home data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="space-y-12">
        <HeroSkeleton />
        <div className="max-w-[1440px] mx-auto px-4 md:px-8 grid grid-cols-2 md:grid-cols-6 gap-6">
          {[...Array(12)].map((_, i) => <MovieCardSkeleton key={i} />)}
        </div>
      </div>
    );
  }

  const featured = newMovies[0];

  return (
    <div className="space-y-12 pb-20 animate-in fade-in duration-500">
      {/* Hero Banner */}
      {featured && (
        <section className="relative h-[70vh] md:h-[85vh] w-full overflow-hidden">
          <div className="absolute inset-0">
            <img 
              src={getImageUrl(featured.poster_url)} 
              alt={featured.name}
              className="w-full h-full object-cover"
              onLoad={(e) => (e.currentTarget.style.opacity = '1')}
              style={{ opacity: 0, transition: 'opacity 0.8s ease-in-out' }}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0F0F0F] via-[#0F0F0F]/60 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent" />
          </div>

          <div className="absolute bottom-1/4 left-4 md:left-12 max-w-3xl space-y-4 md:space-y-8">
            <div className="flex items-center gap-3">
               <span className="bg-red-600 px-3 py-1 rounded text-[10px] font-black tracking-widest uppercase">Mới cập nhật</span>
               <span className="text-sm font-bold text-gray-300 drop-shadow-md">{featured.year} • {featured.lang} • {featured.quality}</span>
            </div>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black leading-none drop-shadow-2xl tracking-tighter uppercase">
              {featured.name}
            </h1>
            <p className="text-gray-300 text-sm md:text-xl line-clamp-2 drop-shadow-lg max-w-2xl font-bold opacity-80 uppercase italic">
              {featured.origin_name}
            </p>
            <div className="flex items-center gap-4">
              <Link 
                to={`/phim/${featured.slug}`}
                className="bg-red-600 hover:bg-red-700 text-white px-10 py-4 rounded-2xl font-black flex items-center gap-3 transition-all transform hover:scale-105 active:scale-95 shadow-2xl shadow-red-600/40 uppercase tracking-widest text-sm"
              >
                <Play className="w-5 h-5 fill-current" /> Xem ngay
              </Link>
              <Link 
                to={`/phim/${featured.slug}`}
                className="bg-white/10 hover:bg-white/20 backdrop-blur-xl border border-white/20 px-10 py-4 rounded-2xl font-black flex items-center gap-3 transition-all uppercase tracking-widest text-sm"
              >
                <Info className="w-5 h-5" /> Chi tiết
              </Link>
            </div>
          </div>
        </section>
      )}

      <div className="max-w-[1440px] mx-auto px-4 md:px-8 space-y-24">
        
        {/* Continue Watching Section */}
        {continueWatching.length > 0 && (
          <section className="animate-in slide-in-from-left-10 duration-700">
            <div className="flex items-center justify-between mb-8">
               <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tighter flex items-center gap-3">
                  <Clock className="w-6 h-6 text-red-600" /> Tiếp tục xem
               </h2>
               <Link to="/thu-vien" className="text-xs font-black text-gray-500 hover:text-white uppercase tracking-widest">Xem tất cả</Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
               {continueWatching.map((item) => (
                 <Link 
                    key={item.slug} 
                    to={`/xem-phim/${item.slug}/${item.episodeSlug}`}
                    className="group relative bg-[#1A1A1A] rounded-2xl overflow-hidden border border-white/5 hover:border-red-600/50 transition-all shadow-2xl"
                 >
                    <div className="aspect-video relative overflow-hidden">
                       <img src={getImageUrl(item.poster)} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                       <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Play className="w-10 h-10 text-white fill-current" />
                       </div>
                    </div>
                    <div className="p-4 space-y-1">
                       <h4 className="text-sm font-bold truncate group-hover:text-red-500 transition-colors">{item.name}</h4>
                       <p className="text-[10px] font-black text-red-500 uppercase tracking-widest">Tập {item.episodeName}</p>
                    </div>
                 </Link>
               ))}
            </div>
          </section>
        )}

        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-black border-l-8 border-red-600 pl-6 uppercase tracking-tighter">Phim mới cập nhật</h2>
            <Link to="/tim-kiem?type=phim-moi" className="text-xs text-gray-500 hover:text-white flex items-center gap-2 group font-black uppercase tracking-widest transition-all">
              Xem tất cả <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {newMovies.map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-black border-l-8 border-red-600 pl-6 uppercase tracking-tighter">Phim bộ hấp dẫn</h2>
            <Link to="/tim-kiem?type=phim-bo" className="text-xs text-gray-500 hover:text-white flex items-center gap-2 group font-black uppercase tracking-widest transition-all">
              Xem tất cả <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {seriesMovies.map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Home;

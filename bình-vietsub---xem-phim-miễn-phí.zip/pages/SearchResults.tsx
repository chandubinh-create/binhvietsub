
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { searchMovies, fetchListByType } from '../services/api';
import { Movie } from '../types';
import MovieCard from '../components/MovieCard';
import { Loader2, Search as SearchIcon, Filter } from 'lucide-react';

const SearchResults: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q');
  const type = searchParams.get('type');
  const category = searchParams.get('category');
  
  const [results, setResults] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        let data;
        if (query) {
          data = await searchMovies(query, page);
          setResults(data.data.items || []);
          setHasMore(data.data.params.pagination.currentPage < data.data.params.pagination.totalPages);
        } else if (type) {
          data = await fetchListByType(type, page);
          setResults(data.data.items || []);
          setHasMore(data.data.params.pagination.currentPage < data.data.params.pagination.totalPages);
        } else if (category) {
          // Note: In a real app, you'd call a genre-specific API endpoint. 
          // For this example using phimapi, we'll fallback to search or a general list.
          data = await searchMovies(category, page);
          setResults(data.data.items || []);
          setHasMore(data.data.params.pagination.currentPage < data.data.params.pagination.totalPages);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [query, type, category, page]);

  const getTitle = () => {
    if (query) return `Kết quả cho: "${query}"`;
    if (type === 'phim-bo') return 'Phim Bộ Mới Nhất';
    if (type === 'phim-le') return 'Phim Lẻ Mới Nhất';
    if (type === 'hoat-hinh') return 'Hoạt Hình Đặc Sắc';
    if (category) return `Phim Thể Loại: ${category.replace('-', ' ').toUpperCase()}`;
    return 'Tất cả phim';
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 md:px-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 py-12">
        <div className="space-y-2">
           <h1 className="text-3xl font-black uppercase tracking-tight border-l-4 border-red-600 pl-4">{getTitle()}</h1>
           <p className="text-gray-500 text-sm font-medium">Khám phá kho tàng phim ảnh tại Bình Vietsub</p>
        </div>
        
        <div className="flex items-center gap-4">
           <button className="flex items-center gap-2 bg-white/5 border border-white/10 px-6 py-2.5 rounded-full hover:bg-white/10 transition-all text-sm font-bold">
              <Filter className="w-4 h-4" /> Lọc nâng cao
           </button>
        </div>
      </div>

      {loading && page === 1 ? (
        <div className="h-[40vh] flex items-center justify-center">
          <Loader2 className="w-10 h-10 text-red-600 animate-spin" />
        </div>
      ) : results.length > 0 ? (
        <div className="space-y-12">
           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
            {results.map(movie => (
              <MovieCard key={movie._id} movie={movie} />
            ))}
          </div>

          {hasMore && (
             <div className="flex justify-center">
                <button 
                  onClick={() => setPage(p => p + 1)}
                  className="bg-red-600 hover:bg-red-700 px-12 py-3 rounded-full font-black text-sm uppercase tracking-widest transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-red-600/20"
                >
                   Tải thêm phim
                </button>
             </div>
          )}
        </div>
      ) : (
        <div className="h-[40vh] flex flex-col items-center justify-center text-center">
           <SearchIcon className="w-16 h-16 text-white/10 mb-4" />
           <p className="text-xl text-gray-500 font-medium">Không tìm thấy kết quả phù hợp.</p>
           <button onClick={() => window.history.back()} className="mt-6 text-red-500 font-bold hover:underline">Quay lại</button>
        </div>
      )}
    </div>
  );
};

export default SearchResults;

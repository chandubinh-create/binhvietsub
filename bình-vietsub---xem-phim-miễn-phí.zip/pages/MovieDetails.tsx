
import React, { useEffect, useState, useContext } from 'react';
import { useParams, Link } from 'react-router-dom';
import { fetchMovieDetail, getImageUrl } from '../services/api';
import { MovieDetail } from '../types';
import { Play, Clock, Star, Users, MapPin, Tag, Loader2, Bookmark, Share2, Info, ChevronRight, Check } from 'lucide-react';
import { ToastContext } from '../App';

const MovieDetails: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [movie, setMovie] = useState<MovieDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    if (slug) {
      fetchMovieDetail(slug)
        .then(data => {
          setMovie(data.movie ? { ...data.movie, episodes: data.episodes } : null);
          setLoading(false);
          
          // Check bookmark status
          const bookmarks = JSON.parse(localStorage.getItem('phim_bookmarks') || '[]');
          setIsBookmarked(bookmarks.some((b: any) => b.slug === slug));
        })
        .catch(() => setLoading(false));
    }
  }, [slug]);

  const toggleBookmark = () => {
    if (!movie) return;
    const bookmarks = JSON.parse(localStorage.getItem('phim_bookmarks') || '[]');
    let updated;
    if (isBookmarked) {
      updated = bookmarks.filter((b: any) => b.slug !== movie.slug);
      showToast('Đã xóa khỏi danh sách yêu thích');
    } else {
      updated = [...bookmarks, { 
        slug: movie.slug, 
        name: movie.name, 
        thumb_url: movie.thumb_url,
        year: movie.year,
        quality: movie.quality
      }];
      showToast('Đã thêm vào danh sách yêu thích');
    }
    localStorage.setItem('phim_bookmarks', JSON.stringify(updated));
    setIsBookmarked(!isBookmarked);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    showToast('Đã sao chép liên kết vào bộ nhớ tạm');
  };

  if (loading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center gap-4 bg-black">
        <Loader2 className="w-12 h-12 text-red-600 animate-spin" />
        <p className="text-gray-500 font-black uppercase tracking-widest text-xs">Đang tải thông tin phim...</p>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="h-[70vh] flex flex-col items-center justify-center text-center px-4">
        <h2 className="text-4xl font-black mb-6 uppercase">Không tìm thấy phim</h2>
        <Link to="/" className="bg-red-600 px-8 py-3 rounded-full font-black uppercase tracking-widest text-xs">Quay về trang chủ</Link>
      </div>
    );
  }

  const firstEpisode = movie.episodes?.[0]?.server_data?.[0];

  return (
    <div className="min-h-screen bg-[#0F0F0F] animate-in fade-in duration-700">
      {/* Header Banner */}
      <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={getImageUrl(movie.thumb_url)} 
            alt={movie.name} 
            className="w-full h-full object-cover blur-2xl scale-110 opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F0F0F] to-transparent" />
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-4 md:px-12 -mt-64 md:-mt-80 relative z-10">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Poster Section */}
          <div className="w-full lg:w-96 shrink-0">
            <div className="aspect-[2/3] rounded-[2rem] overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-white/10 group relative">
              <img 
                src={getImageUrl(movie.poster_url)} 
                alt={movie.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute top-4 left-4">
                 <span className="bg-red-600 text-white font-black px-4 py-2 rounded-xl text-xs uppercase tracking-widest shadow-xl">{movie.quality}</span>
              </div>
            </div>
            
            <div className="mt-8 flex flex-col gap-4">
              {firstEpisode && (
                <Link 
                  to={`/xem-phim/${movie.slug}/${firstEpisode.slug}`}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-3 transition-all transform hover:scale-[1.02] active:scale-95 shadow-2xl shadow-red-600/30 uppercase tracking-[0.2em] text-sm"
                >
                  <Play className="w-6 h-6 fill-current" /> XEM PHIM NGAY
                </Link>
              )}
              <div className="flex gap-3">
                 <button 
                  onClick={toggleBookmark}
                  className={`flex-1 py-4 rounded-2xl flex items-center justify-center gap-3 transition-all font-black uppercase tracking-widest text-xs border ${
                    isBookmarked ? 'bg-green-600/10 border-green-600/50 text-green-500' : 'bg-white/5 hover:bg-white/10 border-white/10 text-white'
                  }`}
                 >
                    {isBookmarked ? <Check className="w-5 h-5" /> : <Bookmark className="w-5 h-5" />}
                    {isBookmarked ? 'Đã lưu' : 'Lưu phim'}
                 </button>
                 <button 
                  onClick={handleShare}
                  className="px-6 bg-white/5 hover:bg-white/10 border border-white/10 py-4 rounded-2xl transition-all active:scale-90"
                 >
                    <Share2 className="w-5 h-5" />
                 </button>
              </div>
            </div>
          </div>

          {/* Info Section */}
          <div className="flex-grow space-y-10">
            <div className="space-y-6">
              <div className="flex flex-wrap items-center gap-3 text-[10px] font-black uppercase tracking-[0.3em] text-red-600">
                <span>{movie.type === 'movie' ? 'Phim Lẻ' : 'Phim Bộ'}</span>
                <ChevronRight className="w-3 h-3" />
                <span className="text-gray-500">{movie.year}</span>
              </div>
              <h1 className="text-5xl md:text-7xl font-black text-white leading-tight tracking-tighter uppercase drop-shadow-2xl">
                {movie.name}
              </h1>
              <h2 className="text-2xl md:text-3xl text-gray-500 font-bold tracking-tight italic">
                {movie.origin_name}
              </h2>
              
              <div className="flex flex-wrap gap-6 text-xs font-black uppercase tracking-widest">
                <div className="flex items-center gap-2 text-yellow-500">
                  <Star className="w-5 h-5 fill-current" />
                  <span>8.9 Đánh giá</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Clock className="w-5 h-5 text-red-600" />
                  <span>{movie.time || '120 Phút'}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Tag className="w-5 h-5 text-red-600" />
                  <span>{movie.quality} • {movie.lang}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm font-medium">
               <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
                  <span className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3">Thông tin sản xuất</span>
                  <div className="space-y-4">
                    <div className="flex gap-3"><MapPin className="w-4 h-4 text-red-500" /> <span className="text-gray-400">Quốc gia:</span> {movie.country.map(c => c.name).join(', ')}</div>
                    <div className="flex gap-3"><Users className="w-4 h-4 text-red-500" /> <span className="text-gray-400">Đạo diễn:</span> {movie.director.join(', ') || 'Đang cập nhật'}</div>
                  </div>
               </div>
               <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
                  <span className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3">Thể loại & Diễn viên</span>
                  <div className="space-y-4">
                    <div className="flex gap-3"><Tag className="w-4 h-4 text-red-500" /> <span className="text-gray-400">Thể loại:</span> {movie.category.map(c => c.name).join(', ')}</div>
                    <div className="flex gap-3"><Users className="w-4 h-4 text-red-500" /> <span className="text-gray-400">Dàn sao:</span> {movie.actor.slice(0, 3).join(', ')}...</div>
                  </div>
               </div>
            </div>

            <div className="relative">
              <h3 className="text-2xl font-black mb-4 flex items-center gap-3 uppercase tracking-tighter">
                <Info className="w-6 h-6 text-red-600" /> Tóm tắt nội dung
              </h3>
              <div 
                className="text-gray-400 leading-relaxed font-bold text-base md:text-lg bg-white/5 p-8 rounded-3xl border border-white/5"
                dangerouslySetInnerHTML={{ __html: movie.content }} 
              />
            </div>

            {/* Episode List */}
            {movie.episodes && movie.episodes.length > 0 && (
              <div className="space-y-8 pb-12">
                <div className="flex items-center gap-6">
                  <h3 className="text-2xl font-black uppercase tracking-tighter">Chọn tập phim</h3>
                  <div className="h-px flex-grow bg-white/10" />
                  <span className="text-[10px] font-black text-gray-500">{movie.episodes[0].server_data.length} TẬP</span>
                </div>
                {movie.episodes.map((server, sIdx) => (
                  <div key={sIdx} className="space-y-6">
                    <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3">
                      {server.server_data.map((ep, eIdx) => (
                        <Link
                          key={eIdx}
                          to={`/xem-phim/${movie.slug}/${ep.slug}`}
                          className="bg-white/5 hover:bg-red-600 border border-white/10 hover:border-red-600 text-center py-3 rounded-xl text-xs font-black transition-all transform hover:scale-110 shadow-lg"
                        >
                          {ep.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;


import React from 'react';
import { Link } from 'react-router-dom';
import { Play } from 'lucide-react';
import { Movie } from '../types';
import { getImageUrl } from '../services/api';

interface MovieCardProps {
  movie: Movie;
  className?: string;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, className = '' }) => {
  return (
    <Link 
      to={`/phim/${movie.slug}`}
      className={`group relative overflow-hidden rounded-lg aspect-[2/3] bg-[#1A1A1A] block ${className}`}
    >
      <img
        src={getImageUrl(movie.poster_url || movie.thumb_url)}
        alt={movie.name}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        loading="lazy"
      />
      
      {/* Badges */}
      <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
        {movie.quality && (
          <span className="bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow-lg uppercase">
            {movie.quality}
          </span>
        )}
        {movie.lang && (
          <span className="bg-black/80 text-white text-[10px] font-medium px-1.5 py-0.5 rounded border border-white/20">
            {movie.lang}
          </span>
        )}
      </div>

      <div className="absolute top-2 right-2 z-10">
         <span className="bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded-full">
            {movie.year}
         </span>
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
        <div className="bg-red-600 rounded-full p-4 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-2xl">
          <Play className="w-8 h-8 fill-current text-white" />
        </div>
      </div>

      {/* Info */}
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black to-transparent">
        <h3 className="text-sm font-bold truncate group-hover:text-red-500 transition-colors">
          {movie.name}
        </h3>
        <p className="text-[10px] text-gray-400 truncate mt-0.5">
          {movie.origin_name}
        </p>
        {movie.episode_current && (
           <p className="text-[10px] text-red-400 font-medium mt-1">
              {movie.episode_current}
           </p>
        )}
      </div>
    </Link>
  );
};

export default MovieCard;


import React from 'react';

export const MovieCardSkeleton = () => (
  <div className="animate-pulse flex flex-col gap-3">
    <div className="aspect-[2/3] bg-white/5 rounded-lg w-full"></div>
    <div className="h-4 bg-white/5 rounded w-3/4"></div>
    <div className="h-3 bg-white/5 rounded w-1/2"></div>
  </div>
);

export const HeroSkeleton = () => (
  <div className="h-[60vh] md:h-[80vh] w-full bg-[#1A1A1A] animate-pulse flex flex-col justify-end p-12 gap-6">
    <div className="h-12 bg-white/5 rounded w-1/2"></div>
    <div className="h-6 bg-white/5 rounded w-1/3"></div>
    <div className="flex gap-4">
      <div className="h-12 bg-white/5 rounded-full w-32"></div>
      <div className="h-12 bg-white/5 rounded-full w-32"></div>
    </div>
  </div>
);
